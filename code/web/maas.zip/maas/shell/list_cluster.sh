#!/bin/bash
sqlite3 /var/www/maas/sahara.db "select clusters.name from clusters;" > /var/www/maas/shell/cluster.txt

