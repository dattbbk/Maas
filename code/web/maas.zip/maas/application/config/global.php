<?php
$GLOBAL['ip_controller'] = '127.0.0.1';
?>
