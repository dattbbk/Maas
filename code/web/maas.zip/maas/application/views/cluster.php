<?php
	if(!isset($_SESSION)) {
		session_start();
	}
	//echo $cluster0;
	$cluster_index[0]=$cluster0;
	$cluster_index[1]=$cluster1;

?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<title>MaaS</title>
	<link href="<?php echo base_url()?>css/style.css" rel="stylesheet" type="text/css" media="screen" />
</head>

<body>
	<div id="wapper">
		<div id="header">
			<b><a>
				Xin chào 
				<?php
					if(isset($_SESSION['uname'])){
						echo $_SESSION['uname'] ;
					}
					else{}
				?>
			</a></b>
			<b><a href="<?php echo base_url()?>index.php/welcome/do_exit"> (Thoát)</a></b>
		</div>
		<div class="clearfix"></div>
		<div id="cluster">
		    <div id="list-vms">
			    <div class="des-row">
			        <div class="col-style-name"><b>Cluster</b></div>
			        <div class="col-style"><b>Mahout</b></div>
			        <div class="col-style"><b>Dataset</b></div>
			        <div class="col-style"><b>Actions</b></div>
			    </div><!--End #des-row-->

				<?php $j=0; foreach ($cluster_index as $p): ?>
		            <?php if ($j%2==0): ?>	   
			            <div class="row">
			                <div class="col-style-name"><u><b><a href="#"><?php echo $p; ?></a></b></u></div>
			                <div class="col-style">Active</div>
			                <div class="col-style"></div>
			                <div class="col-style-name">
			            		<p><a href="#">Install mahout</a><a href="#">Upload dataset</a></p>   
			                </div>
			            </div> <!--End #row-->

			            <?php else: ?>
			            <div class="row" style="background:#f4f4f4;">
			                <div class="col-style-name"><u><b><a href="#"><?php echo $p; ?></a></b></u></div>
			                <div class="col-style">No</div>
			                <div class="col-style"></div>
			                <div class="col-style-name">
			                    <p><a href="#">Install mahout</a><a href="#">Upload dataset</a></p>
			                </div>
			            </div><!--End #row-->
		            <?php endif; ?>
		            <?php $j++; ?>
		        <?php endforeach;?>
		    </div><!-- End #list-vms -->
		</div><!-- End #cluster -->
	</div><!-- End #wapper -->
</body>
</html>