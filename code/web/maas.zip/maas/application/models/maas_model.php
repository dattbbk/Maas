<?php
	if(!isset($_SESSION))
	{
		session_start();
	}
?>
<?php
class Maas_model extends CI_Model{
	private $keystoneDB;
    private $ip_controller;
    public function __construct(){
        parent::__construct();
        global $keystoneDB;
        global $ip_controller;
		//include file config GLOBAL
		include(APPPATH . '/config/' . 'global.php');
		//include file config database keystone
        //include(APPPATH . '/config/' . 'keystoneDB.php');
		//$keystoneDB = $this->load->database($config,true);
		//include(APPPATH . '/config/' . 'clusterDB.php');
		//$clusterDB = $this->load->database($config,true);
		$ip_controller = $GLOBAL['ip_controller'];
        //$this->load->database();
    }

    public function validate(){   	
    	global $ip_controller;
		$ADD_ENDPOINT_TOKEN = 'http://'.$ip_controller.':5000/v2.0/';
        // grab user input
        $username = $this->security->xss_clean($this->input->post('username'));     //$this->input->post(''): Lap gia tri post nhap trong o input
        $password = $this->security->xss_clean($this->input->post('password'));     //xss_clean(): Kiem tra xem co ma doc khong
        $_SESSION['uname'] = $username;

        $f_login = shell_exec("./shell/login.sh Alo1 Alo2 Alo3");
        //echo $f_login;
        return 1;
        /*
        $tenant_name = $this->get_tenant($username);
        if ($tenant_name) {
      	 	# code...
      	 	$data_string = '{
   						 "auth":{
						        "passwordCredentials":{
						            "username":"'.$username.'",
						            "password":"'.$password.'"
						        },
						        "tenantName":"'.$tenant_name.'"
   						 }
			}';
			$ch = curl_init($ADD_ENDPOINT_TOKEN.'tokens');      //Khai bao
			//echo $ADD_ENDPOINT_TOKEN.'/v2.0/tokens';
			curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
			curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);     //Dat thuoc tinh cac bien cho goi du lieu post
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);     //Cai che do lay noi dung tra ve
			curl_setopt($ch, CURLOPT_HTTPHEADER, array(
			'Content-Type: application/json',
			'Content-Length: ' . strlen($data_string))
			);
			$result = curl_exec($ch);   //Thuc thi + luu gia tri vao bien $result
			$result_json = json_decode($result,true);
				
			if(isset($result_json['error'])) return 0;
			else{
                global $tenant_id;

				$token_client = $result_json['access']['token']['id'];
				$tenant_id = $result_json['access']['token']['tenant']['id'];
				$token = array();
				$token['username'] = $username;
				$token['key'] = $token_client;
				$token['tenant_id'] = $tenant_id;
				return $token;
			}
      	}else return 2;
      	*/
    }

    public function list_cluster(){
	$cluster_data = shell_exec("./shell/list_cluster.sh");
		if(!$fw = fopen ("shell/cluster.txt","r")){
		    echo ("File not found");
		}else{
		    //$text = fread ($fw);//Đọc 10 ký tự đầu của file
		    $i=0;
		    while(!feof ($fw)){
		    	$j="cluster".$i;
           		$cluster[$j]=fgets ($fw);
               	$i++;
       		}
		    //echo $text;
		    fclose ($fw);
		return $cluster;
		}
    }





























    public function get_tenant($username){
    	global $keystoneDB;
    	//$query = $keystoneDB->query("call GetTenant(?)", array('username' => $username));
        //Ket noi 3 bang: user, user_tenant_membership va tenant
		$query = $keystoneDB->query("SELECT t3.`name`
									 FROM `user` t1
									 JOIN user_tenant_membership t2 ON t1.id = t2.user_id
	                                 JOIN tenant t3 ON t3.id = t2.tenant_id
	                                 WHERE t1.`name`='$username';");
		$keystoneDB->close();
		if($result = $query->result()){
			foreach ($result as $r) {
				# code...
                return $r->name;
			}
		}else return 0;
    }
	
	public function update_document($data){
		if($_POST['field'] == 0){
			echo "<script>alert('Bạn chưa chọn lĩnh vực!')</script>";
			$this->my_layout->view('frontend/upload_form');
		}
		else{
			//echo $_POST['field'];
			$t=$_SESSION['uname'];
			$this->db->select("id");
			$this->db->where("username",$t);
			$query=$this->db->get("account");
			$Mdata = array(
				"name" => $data['upload_data']['file_name'],
				"size" => $data['upload_data']['file_size'],
				"linked" => $data['upload_data']['full_path'],
				"field_id" => $_POST['field'],
				"account_id" => $_SESSION['idAcc']
			);
			$this->db->insert("document",$Mdata);
			$this->my_layout->view('frontend/upload_success', $data);
		}
    }
	
	public function doLogin(){
		$u=$_POST['username'];
		$p=md5($_POST['password']);
		
		$this->db->select("username,password, id");
        $this->db->where("username",$u);
		$this->db->where("password",$p);
        $query=$this->db->get("account");

		if($query->num_rows() == 0){
			echo "<script>alert('Tên đăng nhập hoặc mật khẩu chưa đúng!')</script>";
			$url = base_url()."index.php/home/dangNhap";
			echo "<meta http-equiv='refresh' content='0;url=$url' />";
		}
		else{
			$_SESSION['uname'] = $u;
			$_SESSION['pass'] = $p;
			$_SESSION['ok'] = '1';
			
			$conn=mysql_connect("localhost","root","dat126899") or die("can't connect this database");
			mysql_select_db("database",$conn);
			$sql="select * from account where username='".$_SESSION['uname']."'";
			$query=mysql_query($sql);
			$row=mysql_fetch_array($query);
			$_SESSION['idAcc']= $row['id'];
		}
	}

	public function doRegister(){
		$uName = $_POST['uname'];
		$pWord = md5($_POST['pword']);
		$mail = $_POST['email'];
		$this->db->select("username");
		$this->db->where("username",$uName);
		$query=$this->db->get("account");
		if($query->num_rows() != 0){
			echo "<script>alert('Tài khoản đã tồn tại! Thử lại...')</script>";
		}
		else{
			$Mdat =  Array(
				"username" => $uName,
				"password" => $pWord,
				"level" => '1',
				"email" => $mail
			);
			$this->db->insert("account",$Mdat);
			
			$_SESSION['uname'] = $uName;
			$_SESSION['pass'] = $pWord;
		}
		
	}
	
	//Xu li su kien chon linh vuc
	public function doChoose(){
		if(!isset($_SESSION['uname'])){
			echo "<script>alert('Bạn chưa đăng nhập!')</script>";
			$url = base_url()."index.php/home/dangNhap";
			echo "<meta http-equiv='refresh' content='0;url=$url' />";
		}
		else{
			$this->db->select("name, size");
			$this->db->where("field_id",$_SESSION['idField']);
			$query2=$this->db->get("document");
			unset($_SESSION['idField']);
			if($query2->num_rows() == 0){
				echo "<script>alert('Vẫn chưa có tài liệu! Đóng góp nhé^^')</script>";
				$url = base_url()."index.php/home/";
				echo "<meta http-equiv='refresh' content='0;url=$url' />";
			}
			else{
				foreach($query2->result() as $row3)
				{
					$data_f['array_document'][] = Array(
						"name" => $row3->name,
						"size" => $row3->size
					);

				}
				//print_r($data_f);
				$this->my_layout->view('frontend/document', $data_f);
			}
		}
	}
	
	public function vAccount(){
		if(!isset($_SESSION['uname'])){
			echo "<script>alert('Bạn chưa đăng nhập!')</script>";
			$url = base_url()."index.php/home/dangNhap";
			echo "<meta http-equiv='refresh' content='0;url=$url' />";
		}
		else{
			$this->db->select("name, size");
			$this->db->where("account_id",$_SESSION['idAcc']);
			$query=$this->db->get("document");
			if($query->num_rows() == 0){
				echo "<script>alert('Vẫn chưa có tài liệu! Đóng góp nhé^^')</script>";
				$url = base_url()."index.php/home/";
				echo "<meta http-equiv='refresh' content='0;url=$url' />";
			}
			else{
				foreach($query->result() as $row)
				{
					$data_d['array_name'][] = Array(
						"name" => $row->name,
						"size" => $row->size
					);
				}
				$this->my_layout->view('frontend/account', $data_d);
			}
		}
	}
	
	public function doSearchKey(){
		$key = $_POST['keySearch'];
		//echo $key;
		$this->db->select("name, size");
		$this->db->where("name",$key);
		$query3=$this->db->get("document");
		if($query3->num_rows() == 0){
			echo "<script>alert('Tài liệu này chưa có!')</script>";
			$url = base_url()."index.php/home/search";
			echo "<meta http-equiv='refresh' content='0;url=$url' />";
		}
		else{
			foreach($query3->result() as $row3)
			{
				$data_s['array_document'][] = Array(
					"name" => $row3->name,
					"size" => $row3->size,
				);

			}
			$this->my_layout->view('frontend/document', $data_s);
		}
	}
}
?>
