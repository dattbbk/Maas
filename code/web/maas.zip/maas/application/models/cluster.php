<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<title>MaaS</title>
	<meta name="keywords" content="" />
	<meta name="description" content="" />
	
</head>

<body>
	<div id="wapper">
		<div id="header">

		</div>

		<div id="cluster">
		    <div id="list-vms">
			    <div class="des-row">
			        <div class="col-style-2">Tên cluster</div>
			        <div class="col-style-2">Mahout</div>
			        <div class="col-style-2">Dataset</div>
			        <div class="col-style-2">Actions</div>
			    </div><!--End #des-row-->

				<?php $colors = array("red","green","blue","yellow"); $j=0; foreach ($colors as $p): ?>
		            <?php if ($j%2==0): ?>	   
			            <div class="row">
			                <div class="col-style-2"><a href="#"> Cluster 01</div>
			                <div class="col-style-2">Active</div>
			                <div class="col-style-2">u.data</div>
			                <div class="col-style-2">
			                    <form action="">
			                        <select>
			                            <option value="">Chọn action</option>
			                            <option value="">Install mahout</option>
			                            <option value="">Upload dataset</option>
			                            <option value="">Restart</option>
			                            <option value="">Delete</option>
			                        </select>
			                    </form>
			                </div>
			            </div> <!--End #row-->
			            <?php else: ?>
			            <div class="row" style="background:#f4f4f4;">
			                <div class="col-style-2"><a href="#">Cluster 02</div>
			                <div class="col-style-2">No</div>
			                <div class="col-style-2"></div>
			                <div class="col-style-2">
			                    <form action="">
			                        <select>
			                            <option value="">Chọn action</option>
			                            <option value="">Install mahout</option>
			                            <option value="">Upload dataset</option>
			                            <option value="">Restart</option>
			                            <option value="">Delete</option>
			                        </select>
			                    </form>
			                </div>
			            </div><!--End #row-->
		            <?php endif; ?>
		            <?php $j++; ?>
		        <?php endforeach;?>
		    </div><!-- End #list-vms -->
		</div><!-- End #cluster -->
	</div><!-- End #wapper -->
</body>
</html>