#!/bin/bash
sqlite3 /var/www/maas/sahara.db "select clusters.info from clusters where clusters.name='$1';" > /var/www/maas/shell/info.txt

