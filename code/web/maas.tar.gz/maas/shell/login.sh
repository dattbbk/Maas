#!/bin/bash
curl -i $1'tokens' -X POST -H "Content-Type: application/json" -H "Accept: application/json"  -d '{"auth": {"tenantName": "", "passwordCredentials": {"username": "'$2'", "password": "'$3'"}}}' > 1.txt

key="id"
file_in="1.txt"
if [ `grep -l $key $file_in` ];	then
	echo 1
else
	echo 2
fi
rm $file_in

