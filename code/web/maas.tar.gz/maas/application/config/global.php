<?php
	/* Hay thay $ip_controller_openstack bang ip openstack controller cua ban */
	$GLOBAL['ip_controller'] = '$ip_controller_openstack';
?>
