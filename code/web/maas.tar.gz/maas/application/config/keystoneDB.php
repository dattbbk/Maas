<?php
$config['hostname'] = "127.0.0.1";
$config['username'] = "root";
$config['password'] = "dat126899";
$config['database'] = "keystone";
$config['dbdriver'] = "mysql";
$config['dbprefix'] = "";
$config['pconnect'] = FALSE;
$config['db_debug'] = TRUE;
$config['cache_on'] = FALSE;
$config['cachedir'] = "";
$config['char_set'] = "utf8";
$config['dbcollat'] = "utf8_general_ci";
?>
