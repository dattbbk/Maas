<?php
$db['default']['hostname'] = 'sqlite:/var/www/maas/sahara.db';
$db['default']['username'] = '';
$db['default']['password'] = '';
$db['default']['database'] = '';
$db['default']['dbdriver'] = 'pdo';
$db['default']['dbprefix'] = '';
?>
