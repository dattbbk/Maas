<?php
	if(!isset($_SESSION)) {
		session_start();
	}

	$upload=array(
	    "name" => "img",
	    "size" => "25",
	);
	//echo $cluster0;
	//$i=0;
	//$tmp="cluster".$i;
	//echo $$tmp;
	//$cluster_index[0]=$cluster0;
	//$cluster_index[1]=$cluster1;
	
	$i=0;
	while (true) {
		$tmp="cluster".$i;
		if ($$tmp!="") {
			$cluster_index[$i]=$$tmp;
			$i++;
		}
		else{
			break;
		}
	}
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<title>MaaS</title>
	<link href="<?php echo base_url()?>css/style.css" rel="stylesheet" type="text/css" media="screen" />
</head>

<body>
	<div id="wapper">
		<div id="header">
			<b><a>
				Xin chào 
				<?php
					if(isset($_SESSION['uname'])){
						echo $_SESSION['uname'] ;
					}
					else{}
				?>
			</a></b>
			<b><a href="<?php echo base_url()?>index.php/welcome/do_exit"> (Thoát)</a></b>
		</div>
		<div class="clearfix"></div>
		<div id="cluster">
		    <div id="list-vms">
			    <div class="des-row">
			        <div class="col-style-name"><b>Cluster</b></div>
			        <div class="col-style"><b>Mahout</b></div>
			        <div class="col-style"><b>Action</b></div>
			    </div><!--End #des-row-->

				<?php $j=0; foreach ($cluster_index as $p): ?>
		            <?php if ($j%2==0): ?>	   
			            <div class="row">
			                <div class="col-style-name"><u><b><a href="#"><?php echo $p; ?></a></b></u></div>
			                <div class="col-style">Active</div>
			                <div id="clusterid-<?php echo $p; ?>" class="col-style">
			                    <p>Install mahout</p>
			                </div>
			            </div> <!--End #row-->

			            <?php else: ?>
			            <div class="row" style="background:#f4f4f4;">
			                <div class="col-style-name"><u><b><a href="#"><?php echo $p; ?></a></b></u></div>
			                <div class="col-style">No</div>
			                <div id="clusterid-<?php echo $p; ?>" class="col-style">
			                    <p>Install mahout</p>
			                </div>
			            </div><!--End #row-->
		            <?php endif; ?>
		            <?php $j++; ?>
		        <?php endforeach;?>
		    </div><!-- End #list-vms --><br />
		</div><!-- End #cluster --><br />

		<div id="cluster">
			<div class="des-row">
			      <div class="col-style-name"><b>Upload dataset</b></div>  
			</div><br />
	    	<?php
		        echo form_open_multipart(base_url()."index.php/welcome/do_upload");
		        echo form_upload($upload);
		        echo form_label(" ").form_submit("ok", "Upload");
		        echo form_close();
		    ?>    
		    <br />
		    <p><b>List dataset: </b></p>
		    <br /><br />
		</div><!-- End #updataset -->
	</div><!-- End #wapper -->
</body>
</html>